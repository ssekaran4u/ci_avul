<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['logo']         = 'Avul - Simple Codeigniter Application';
$config['site_name']    = 'Avul - Simple Codeigniter Application';
